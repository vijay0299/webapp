package com.nseindia.b2.webapp.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.nseindia.b2.webapp.models.Admin;
import com.nseindia.b2.webapp.models.Blogger;
import com.nseindia.b2.webapp.models.Response;

@Controller
public class BaseController {
	@Autowired
	RestTemplate restTemplate;
	
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	
//	@RequestMapping("/a")
//	public String admin(Model model) {
//		BloggerList list = restTemplate.getForObject("http://localhost:8081", BloggerList.class);
//		model.addAttribute(BloggerList);
//		model.addAttribute("authors", BloggerList.getAuthors());
//	
//		return "author"; 
//	}
	
	@GetMapping("/admin/add")
	public String getAddAdmin() {
		return "adminDetails";
	}
	
	@GetMapping("/blogger/add")
	public String getAddBlogger() {
		return "bloggerDetails";
	}
	
	@PostMapping("/admin/add")
	public String postAddAdmin(@RequestParam("title") String title, @RequestParam("body") String body,@RequestParam("summary") String summary, Model model) {
		
		Admin admin = new Admin();
		admin.setTitle(title);
		admin.setBody(body);
		admin.setSummary(summary);
		
		Response resp = restTemplate.postForObject("http://localhost:8080/", admin, Response.class);
		
		model.addAttribute("message",resp.getAdmin());
		
		return "adminDetails";
	}
	
	@PostMapping("/blogger/add")
	public String postAddBlogger(@RequestParam("title") String title, @RequestParam("body") String body,@RequestParam("summary") String summary, Model model) {
		
		Blogger blogger = new Blogger();
		blogger.setTitle(title);
		blogger.setBody(body);
		blogger.setSummary(summary);
		
		Response resp = restTemplate.postForObject("http://localhost:8080/", blogger, Response.class);
		
		model.addAttribute("message",resp.getBlogger());
		
		return "bloggerDetails";
	}
}